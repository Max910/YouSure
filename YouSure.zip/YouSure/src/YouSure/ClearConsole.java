package YouSure;
// this class is only to generate white space
    public class ClearConsole {
         void cs() {
            for (int i = 0; i < 38; ++i){
                System.out.println();
            }
        }
        void cs2(){
            for (int i = 0; i < 10; ++i){
                System.out.println();
            }
        }

    }

